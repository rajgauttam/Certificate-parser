package com.cisco.nm.vms.api.certificate.node;

/**
 * @author rgauttam
 *
 * @param <T>
 */
public abstract class AbstractCertificateNode {

}
